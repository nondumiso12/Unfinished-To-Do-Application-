<template>
    <div id="todoAppViewWrapper">
        <!-- page heading -->
        <h1>Tasks</h1>

        <div class="todoAppWrapper">
            <!-- input -->
            <div class="input-wrapper">
                <input v-model="input" type="text" placeholder="Enter a new Task" @keyup.enter="addToDo()">
                <div class="icon-wrapper" @click="addToDo()">
                    <img src="../assets/add.png" />
                </div>
            </div>

            <!-- unfinished item list -->
            <h2 v-if="todos.length > 0">Doing</h2>
            <div class="todoListWrapper">
                <div v-for="item in todos" :class="(item.done)? 'todo-item done' : 'todo-item'" :ref="item.id">
                    <!-- item label -->
                    <div :class="(item.editing)? 'label editing' : 'label'">
                        <input :id="`input-${item.id}`" type="text" :disabled="!item.editing" :value="item.label" @keyup.enter="updateToDo(item.id)">
                        <div v-if="item.editing" class="icon-wrapper" @click="updateToDo(item.id)" title="Save">
                            <img src="../assets/done.png" />
                        </div>
                        <div v-if="item.editing" class="icon-wrapper" @click="item.editing = false" title="Cancel">
                            <img src="../assets/close.png" />
                        </div>
                    </div>

                    <!-- done icon -->
                    <div v-if="!item.editing" class="icon-wrapper" @click="markToDoAsDone(item.id)" title="Mark as done">
                        <img src="../assets/done.png" />
                    </div>

                    <!-- delete icon -->
                    <div v-if="!item.editing" class="icon-wrapper" @click="deleteToDo(item.id)" title="Delete Task">
                        <img src="../assets/delete.png" />
                    </div>

                    <!-- edit icon -->
                    <div v-if="!item.editing" class="icon-wrapper" @click="editToDo(item.id)" title="Edit Task">
                        <img src="../assets/edit.png" />
                    </div>
                </div>
            </div>

            <!-- finished item list -->
            <h2 v-if="done.length > 0">Done</h2>
            <div class="todoListWrapper done">
                <div v-for="item in done" :class="(item.done)? 'todo-item done' : 'todo-item'" :ref="item.id">
                    <!-- item label -->
                    <div class="label" @click="markToDoAsNotDone(item.id)">{{ item.label }}</div>

                    <!-- done icon -->
                    <div class="icon-wrapper" @click="markToDoAsNotDone(item.id)" title="Redo Task">
                        <img src="../assets/redo.png" />
                    </div>

                    <!-- delete icon -->
                    <div class="icon-wrapper" @click="deleteToDo(item.id, true)" title="Delete Task">
                        <img src="../assets/delete.png" />
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<style scoped>
    #todoAppViewWrapper {
        width: 100dvw;
        min-height: 100dvh;
        padding-top: 10%;
        background-color: #E55C8A;

        display: flex;
        flex-direction: column;
        align-items: center;
    }
    #todoAppViewWrapper h1 {
        font-size: 35px;
        font-weight: 400;
        color: #fff;
        margin-bottom: 20px;
    }

    .todoAppWrapper {
        width: 40%;
        

        display: flex;
        flex-direction: column;
    }
    .todoAppWrapper h2 {
        font-size: 25px;
        font-weight: 400;
        color: #fff;
        margin-top: 10px;
        margin-bottom: 0px;
        text-decoration: underline;
    }
    .todoAppWrapper .input-wrapper {
        width: 100%;
        height: 50px;
        border: none;  
        border-radius: 8px;
        box-shadow: 0 10px 20px rgba(0,0,0,0.19), 0 6px 6px rgba(0,0,0,0.23); 
        background-color: #343B41;

        display: flex;
        align-items: center;
        justify-content: space-between;
    }
    .todoAppWrapper .input-wrapper input {
        width: 90%;
        height: 100%;
        border: none;
        border-radius: 8px;
        background-color: transparent;
        font-size: 20px;
        color: #fff;
        padding: 0 20px;
    }
    .todoAppWrapper .input-wrapper .icon-wrapper {
        width: 10%;
        cursor: pointer;

        display: flex;
        align-items: center;
        justify-content: center;
    }
    .todoAppWrapper .input-wrapper .icon-wrapper img {
        width: 60%;
    }

    .todoListWrapper {
        width: 100%;
        margin-top: 20px;
        

        display: flex;
        flex-direction: column;
    }
    .todoListWrapper .todo-item {
        width: 100%;
        padding: 10px;
        margin-bottom: 10px;
        border-left: solid 4px #2e00a2;
        border-radius: 0px 8px 8px 0px;
        background-color: #fefefe;
        transition: all 200ms ease-in-out;

        position: relative;

        display: flex;
        align-items: center;
        justify-content: space-between;
    }
    .todoListWrapper.done .todo-item {
        border-left: solid 4px #960202;
        border-radius: 0px 8px 8px 0px;
        background-color: #cb7070;
    }
    .todoListWrapper .todo-item:hover {
        transform: scale(1.04);
    }
    .todoListWrapper .todo-item .strike-through {
        width: 100%;
        border-bottom: solid 1px #000;

        position: absolute;
        left: 0;
        right: 0;

        display: none;
    }
    .todoListWrapper .todo-item.done .strike-through {
        display: block;
    }
    .todoListWrapper .todo-item .label {
        width: 90%;
        font-size: 20px;
        color: #000;

        display: flex;
        align-items: center;
    }
    .todoListWrapper .todo-item .label.editing {
        width: 100%;
    }
    .todoListWrapper .todo-item .label input {
        width: 100%;
        border: none;
        padding: 5px;
        background-color: transparent;
    }
    .todoListWrapper .todo-item.done .label {
        text-decoration: line-through
    }
    .todoListWrapper .todo-item .icon-wrapper {
        width: 10%;
        cursor: pointer;
        transition: all 200ms ease-in-out;

        display: flex;
        align-items: center;
        justify-content: center;
    }
    .todoListWrapper .todo-item .icon-wrapper:hover img {
        transform: scale(1.4);
    }
    .todoListWrapper .todo-item .icon-wrapper img {
        width: 50%;
        transition: all 200ms ease-in-out;
    }
</style>

<script setup>
    import { ref } from 'vue'
    // import { FontAwesomeIcon } from '@fortawesome/vue-fontawesome'

    // Get saved data from localStorage
    const storageKey = 'todos'
    const storageKey2 = 'done_todos'
    const localStorage_todos = localStorage.getItem(storageKey) ? JSON.parse(localStorage.getItem(storageKey)) : [];
    const localStorage_done_todos = localStorage.getItem(storageKey2) ? JSON.parse(localStorage.getItem(storageKey2)) : [];

    const input = ref('')
    const todos = ref(localStorage_todos)
    const done = ref(localStorage_done_todos)

    // generate random ID
    const getId = (len) => Math.random().toString(36).substring(2,len+2)

    // add a new task
    const addToDo = () => {
        // make sure we only add if something was typed
        if (input.value.length >= 4) {
            // create new todo
            const newToDo = { id: getId(8), label: input.value, done: false, editing: false }

            // add todo to this list
            todos.value.push(newToDo)
            
            // clear out input value
            input.value = ''

            // update local storage
            updateLocalStorage()
        }       
    }

    // remove a task
    const deleteToDo = (id, calledFromDoneList=false) => {
        //-- Task 2: Implement Task Deletion
        const todoIndex = todos.value.findIndex(task => task.id === id);
    if (todoIndex !== -1) {
        todos.value.splice(todoIndex, 1); // Remove the task from todos
    } else if(calledFromDoneList) {
        // Check if the task exists in the done array
        const doneIndex = done.value.findIndex(task => task.id === id);
        if (doneIndex !== -1) {
            done.value.splice(doneIndex, 1); // Remove the task from done
        } else {
            console.error("Task not found"); // Task not found in either list
            return;
        }
    }
    }

    // edit existing task
    const editToDo = (id) => {
        todos.value.forEach(item => {
            if (item.id == id) {
                // focus input
                const input = document.querySelector(`[id^="input-${id}"]`)                
                setTimeout(() => {
                    input.focus()
                }, 200);

                // set editing to true
                item.editing = true
            }
        })

        // update local storage
        updateLocalStorage()
    }

    // update existing task
    const updateToDo = (id) => {
        //-- Task 5: Implement the markToDoAsNotDone Functionality
        const todoIndex = todos.value.findIndex(task => task.id === id);
        const input = document.querySelector(`[id^="input-${id}"]`)  
        if (todoIndex !== -1) {
            todos.value[todoIndex].label = input.value;   // Set editing back to false
            todos.value[todoIndex].editing = false;   // Set editing back to false
        }
    }

    // mark task as done
    const markToDoAsDone = (id) => {
        //-- Task 3: Implement the markToDoAsDone Functionality
        const todoIndex = todos.value.findIndex(task => task.id === id);
        if (todoIndex !== -1) {
            // Move the task to the done array
            const taskToMove = todos.value[todoIndex];
            taskToMove.status = "Done"; // Update the status
            done.value.push(taskToMove); // Add to done array
            todos.value.splice(todoIndex, 1); // Remove from todos

            // Update localStorage
            updateLocalStorage();
        } else {
            console.error("Task not found in 'Doing' list"); // Task not found
        }
    }

    // mark task as not done
    const markToDoAsNotDone = (id) => {
         //-- Task 4: Implement the markToDoAsNotDone Functionality
         const doneIndex = done.value.findIndex(task => task.id === id);
        if (doneIndex !== -1) {
            // Move the task back to the todos array
            const taskToMove = done.value[doneIndex];
            taskToMove.status = "Doing"; // Update the status
            todos.value.push(taskToMove); // Add to todos array
            done.value.splice(doneIndex, 1); // Remove from done

            // Update localStorage
            updateLocalStorage();
        } else {
            console.error("Task not found in 'Done' list"); // Task not found
        }
    }

    // update local storage
    const updateLocalStorage = () => {
        localStorage.setItem(storageKey, JSON.stringify(todos.value));
        localStorage.setItem(storageKey2, JSON.stringify(done.value));
    }
</script>